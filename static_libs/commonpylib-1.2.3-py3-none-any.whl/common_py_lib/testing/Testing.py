import inspect
from functools import wraps
from typing import Callable, Any


def run_test(test_class):
    """
    Run method for running tests in given class.
    Ignores init function in class, if exists.
    """
    instance_of_test_class = test_class()
    methods = [name for name, value in
               inspect.getmembers(test_class, inspect.isfunction) if
               name != '__init__']  # turn on test mode

    # Main cycle for run tests
    for method in methods:
        getattr(instance_of_test_class, method)


def parametrize(**default_kwargs):
    """
    For parametrized tests in app
    :param default_kwargs:
    :return: None
    """
    def decorator(function) -> Callable:
        @wraps(function)
        def wrapper(*args, **kwargs) -> Any:
            return function(*args, **{**default_kwargs, **kwargs})

        return wrapper

    return decorator
