"""
Simple conversion functions
"""


def to_map(to_conver: list[str]) -> dict[str, str]:
    """
    Conversion into string dictionary
    """
    from common_py_lib.strings.Strings import clear_str
    to_return: dict[str, str] = dict()
    for elem in to_conver:
        elem_name: str
        elem_ver: str
        split_elem_list = elem.split('\\')  # split by slash
        elem_name = clear_str(split_elem_list[0].strip())
        if len(split_elem_list) != 1:
            elem_ver = split_elem_list[1].strip()
        else:
            elem_ver = ''
        to_return[elem_name] = elem_ver
    return to_return


def to_list(to_conver: list[str]) -> list[str]:
    """
    Conversion into string list
    """
    to_return: list[str] = list()
    if len(to_conver) > 0:
        for elem in to_conver:
            if elem != '[]' and ('[' not in elem or '' not in elem):
                to_return.append(elem)
        return to_return
    else:
        return to_return
