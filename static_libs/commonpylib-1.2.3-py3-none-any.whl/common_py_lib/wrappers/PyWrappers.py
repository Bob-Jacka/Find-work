import datetime
import time
from functools import wraps
from typing import Any, Callable


def timing(func):
    """
    Simply count time of function call
    :param func: function to count time
    :return: function result
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"{func.__name__}: {round(elapsed, 4)} c")
        return result

    return wrapper


def repeat(n=1):
    """
    Simply repeat functionality by n times
    :param n: how many to repeat
    :return: result if true
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            result = None
            for _ in range(n):
                result = func(*args, **kwargs)
            return result

        return wrapper

    return decorator


def safe_log(function) -> Callable:
    """
    Log function execution with try/except block
    :param function: function object to invoke
    :return: Decorator function
    """

    def wrapper(*args, **kwargs) -> Any:
        log_msg: str = f'[{datetime.datetime.now()}]: invoked function with name: "{function.__name__}"'
        print('\033[97m' + log_msg + '\033[00m')
        try:
            r = function(*args, **kwargs)
            return r
        except Exception as e:
            print(f'[{datetime.datetime.now()}]: An exception occurred while function invoke: {e} ""')

    return wrapper


def write_log(function) -> Callable:
    """
    Log function execution and write to file.
    Can write invocation to file.
    :param function: function object to invoke
    :return: Decorator function
    """

    def wrapper(*args, **kwargs) -> Any:
        log_msg: str = f'[{datetime.datetime.now()}]: invoked function with name: "{function.__name__}"'
        print('\033[97m' + log_msg + '\033[00m')
        r = function(*args, **kwargs)
        with open('logfile.log') as log_file:
            log_file.write(log_msg + '\n')
        return r

    return wrapper


def log(function) -> Callable:
    """
    Log function invocation
    :param function: function object to invoke
    :return: Decorator function
    """

    def wrapper(*args, **kwargs) -> Any:
        maybe_class = function.__qualname__.split('.')[0]
        log_msg: str = f'[{datetime.datetime.now()}]: invoked function with name: "{function.__name__}"' + (
                " in class " + maybe_class) if len(maybe_class) > 0 else ''
        print('\033[97m' + log_msg + '\033[00m')
        r = function(*args, **kwargs)
        return r

    return wrapper
