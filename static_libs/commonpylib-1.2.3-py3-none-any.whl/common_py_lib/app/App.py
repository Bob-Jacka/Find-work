from abc import ABC, abstractmethod


class App(ABC):
    @abstractmethod
    def start_app(self):
        pass

    @abstractmethod
    def exit_from_app(self):
        pass
