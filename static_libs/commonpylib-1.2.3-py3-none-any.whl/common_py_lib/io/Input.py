user_input_cursor: str = '>> '


#####Simple input functions
def int_input(optional_point_name: str = '') -> int:
    """
    Simple version of integer input.
    Do not check for condition
    :return: int value
    """
    print(optional_point_name)
    user_input = int(input(user_input_cursor))
    return user_input


def string_input(optional_point_name: str = '') -> str:
    """
    Simple version of string input.
    Do not check for condition
    :return: string value
    """
    print(optional_point_name)
    user_input = input(user_input_cursor)
    return user_input


def float_input(optional_point_name: str = '') -> float:
    """
    Simple version of float input.
    Do not check for condition
    :return: float value
    """
    print(optional_point_name)
    user_input = float(input(user_input_cursor))
    return user_input


#####Simple input functions

#####Checking functions
def check_int_input(check_cond: int, optional_point_name: str = '') -> int | None:
    """
    Simple version of integer input.
    Do check for condition
    :return: int value
    """
    print(optional_point_name)
    user_input = int(input(user_input_cursor))
    if user_input in check_cond:
        return user_input
    else:
        return None


def check_string_input(check_cond, optional_point_name: str = '') -> str | None:
    """
    Simple version of string input.
    Do check for condition
    :return: string value
    """
    print(optional_point_name)
    user_input = input(user_input_cursor)
    if user_input in check_cond:
        return user_input
    else:
        return None


def check_float_input(check_cond, optional_point_name: str = '') -> float | None:
    """
    Simple version of float input.
    Do check for condition
    :return: float value
    """
    print(optional_point_name)
    user_input = float(input(user_input_cursor))
    if user_input in check_cond:
        return user_input
    else:
        return None


#####Checking functions

##### Checking infinity loops functions
def check_infinity_int_input(check_cond: int, point_name: str) -> int | None:
    """
    Simple version of integer input.
    Do check for given condition
    :return: int value
    """
    while True:
        print(point_name)
        user_input = int(input(user_input_cursor))
        if user_input in range(check_cond):
            return user_input
        else:
            continue


def check_infinity_string_input(check_cond, point_name: str) -> str | None:
    """
    Simple version of string input.
    Do check for given condition
    :return: string value
    """
    while True:
        print(point_name)
        user_input = input(user_input_cursor)
        if user_input in check_cond:
            return user_input
        else:
            continue


def check_infinity_float_input(check_cond, point_name: str) -> float | None:
    """
    Simple version of float input.
    Do check for given condition
    :return: float value
    """
    while True:
        print(point_name)
        user_input = float(input(user_input_cursor))
        if user_input in check_cond:
            return user_input
        else:
            continue


def int_input_from_user(values_range=None, topic: str = '') -> int | None:
    """
    Error safety static function for input integer number from user.
    :param values_range: accepts if inputted value in this range.
    :param topic: *optional argument.
    :return: integer number from user.
    """
    try:
        if topic != '':
            print(topic)
        print(user_input_cursor, end='')
        user_input = int(input())
        if values_range is not None:
            if user_input in range(values_range):
                print('Value in given range')
                return user_input
        return user_input
    except Exception as e:
        print(f'Error occurred in int_input_from_user function - {e.with_traceback(None)}.')


def safe_int_input_from_user(values_range=None, topic: str = '') -> int:
    """
    Error safety static function for input integer number from user.
    :param values_range: accepts if inputted value in this range.
    :param topic: *optional argument.
    :return: integer number from user or empty string in case of error.
    """
    try:
        if topic != '':
            print(topic)
        print(user_input_cursor, end='')
        user_input = int(input())
        if values_range is not None:
            if user_input in range(values_range):
                print('Value in given range')
                return user_input
            else:
                return -1
        return user_input
    except Exception as e:
        print(f'Error occurred in int_input_from_user function - {e.with_traceback(None)}.')
        return -1


def str_input_from_user(topic: str = '') -> str | None:
    """
    Error safety static function for input string from user.
    :param topic: *optional argument.
    :return: string from user input or "None" if error occurred.
    """
    try:
        if topic != '':
            print(topic)
        print(user_input_cursor, end='')
        user_input = str(input())
        if not user_input.isnumeric() and not user_input.isspace():
            return user_input
    except Exception as e:
        print(f'Error occurred in str_input_from_user function - {e.with_traceback(None)}.')


def safe_str_input_from_user(topic: str = '') -> str:
    """
    Error safety static function for input string from user, checks for errors and return empty string.
    :param topic: *optional argument.
    :return: string from user input or "" if error occurred.
    """
    try:
        if topic != '':
            print(topic)
        print(user_input_cursor, end='')
        user_input = str(input())
        if not user_input.isnumeric() and not user_input.isspace():
            return user_input
        else:
            return ''
    except Exception as e:
        print(f'Error occurred in str_input_from_user function - {e.with_traceback(None)}.')
        return ''


def check_infinity_int_input_with_exit(check_cond: int, point_name: str, stop_int=666) -> int | None:
    """
    Simple version of integer input.
    Do check for given condition
    :return: int value or 0 if exit
    """
    while True:
        print(point_name)
        print(f'Enter {stop_int} to exit from check')
        user_input = int(input(user_input_cursor))
        if user_input in range(check_cond):
            return user_input
        elif user_input == stop_int:
            return stop_int
        else:
            continue


def user_input_with_exit(values_range: int = None, stop_word=None) -> int | str | None:
    """
    Error safety static function for input string or integer number from user, that supports exit from loop.
    Input value can be string or integer.
    :param stop_word: BDSM word
    :param values_range: accepts if inputted value in this range.
    :return: integer number from user or "exit" value if user wants to exit loop.
    """
    try:
        print(user_input_cursor, end='')
        user_input: int | str = input()
        if user_input.isdigit():
            user_input = int(user_input)
            if values_range is not None and user_input in values_range:
                print('Value in given range.')
                return user_input
            return user_input
        else:
            if user_input == stop_word:
                return user_input
    except Exception as e:
        print(f'Error occurred in input_from_user function - {e.with_traceback(None)}.')
