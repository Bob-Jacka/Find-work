"""
Filesystem common abstraction
"""
import datetime
import os
import platform
import shutil
import sys
from os import PathLike
from pathlib import Path

from common_py_lib.entities.Formatter import TextAnsiFormatter
from common_py_lib.io.Input import int_input

CLOSE_MENU_CODE: int = 666


class FileSystem:
    """
    Simple wrapper class for interaction with file system
    """

    current_dir: str | PathLike

    def __init__(self, current_directory: str):
        self.current_dir = current_directory

    def move_upper(self) -> None:
        """
        Move upper in file system tree
        :return: None
        """

        self.current_dir = Path(self.current_dir).parent

    def print_current_dir_files(self) -> None:
        for num, dir_name in enumerate(os.listdir(self.current_dir)):
            print(f'{num}: {dir_name}')

    def get_current_dir_files(self):
        return [x for x in enumerate(os.listdir(self.current_dir))]

    def move_lower(self):
        """
        Move lower in file system tree
        :return: None
        """
        p = Path('.')  # check current directory
        dir_list = [x for x in p.iterdir() if x.is_dir()]
        TextAnsiFormatter.prGreen('Available directories:')
        if len(dir_list) == 0:
            TextAnsiFormatter.prRed('There are no directories nearby')
        else:
            dir_counter = 0  # change value to zero if you are programmer
            for dir in dir_list:
                print(f'{dir_counter}: {dir.name}')
                dir_counter += 1

            print()  # just empty line
            print(f'Or {CLOSE_MENU_CODE}: to exit this menu')

            while True:
                dir_number = int_input('Enter dir number to move in')
                if dir_number in range(len(dir_list)):
                    self.current_dir = dir_list[dir_number].as_posix()
                    break
                elif dir_number == int(CLOSE_MENU_CODE):
                    TextAnsiFormatter.prYellow('Close menu')
                    break

    def resolve_cli_args(self) -> dict[str, str | int] | None:
        """
        Function for accessing CLI arguments
        :return: tuple with arguments or None if no arg given
        """
        sys_args = sys.argv
        lenght = len(sys_args)
        if lenght > 1:
            resolved_args: dict[str, str | int] = dict()  # dict with split arguments
            for param in sys_args:
                if '--' in param and '=' in param:
                    arg_pair = param.split('=')
                    arg_name = arg_pair[0]  # name of the argument, ex. web_ui_port
                    arg_value = arg_pair[1]  # value of the argument, ex. 127.0.0.1
                    resolved_args[arg_name] = arg_value
                else:
                    raise Exception('Wrong argument received, expect arg with "--" and "="')
            return resolved_args
        elif lenght == 2 and sys_args[1] == 'help':
            self.print_help()
        else:
            return None

    def print_help(self, text: str = ""):
        print(f"""
        {text}
        """)

    def do_backup_copy(self) -> None:
        """
        Function for backup your books in given directory (Download dir).
        :return: None
        """
        print('Backup books invoked')
        save_path: str | os.PathLike
        if sys.platform.system() == 'Windows':
            save_path = Path.home().as_uri() + os.sep + 'Downloads'
            print('Windows user path to Downloads')
        elif platform.system() == 'Linux':
            save_path = Path.home().as_uri() + os.sep + 'Downloads'
            print('Linux user path to Downloads')
        else:
            raise Exception('Unknown operating system, not implemented yet.')

        for dir in os.listdir(self.current_dir):
            self.copy_fs_entity(dir, save_path)
            print(f'File - {dir} backed up in {save_path}')

    def reset_data(self) -> None:
        """
        Method for deleting all book data (exclude file with book read).
        Also home directory of the app will be saved.
        :return: None
        """
        while True:
            print('Do you really want to delete all files data? yes (y) or no (n)')
            user_choice = input('>> ')
            if user_choice == 'yes' or user_choice == 'y':
                print('Reset data is invoked')
                dir_list = self.get_book_data_dirs_list()
                for dir in dir_list:
                    self.delete_fs_entity(dir)
            elif user_choice == 'no' or user_choice == 'n':
                print('Reset data canceled')
            else:
                print('Wrong choice, try again')
                continue

    def move_fs_entity(self, path: str | os.PathLike, dir_name: str = ''):
        """
        Save your book in central directory (app installation home)
        :param path: path from where you want to copy read book
        :param dir_name: *optional parameter, special for directory copying. Use for creating new directory and copy all into
        :return: None
        """
        if path is not None:
            if os.path.isfile(path):
                try:
                    shutil.copy2(path, self.current_dir)  # {src} {dest}
                    print('Book save in central directory')
                except Exception as e:
                    print(f'Error occurred while saving book in central dir - {e}')

            elif os.path.isdir(path):
                try:
                    new_save_point_path = self.current_dir + os.sep + dir_name
                    os.mkdir(new_save_point_path)  # create new directory, instead of deleting old
                    shutil.copytree(path, new_save_point_path, dirs_exist_ok=True)  # {src} {dest}
                    print('Directory save in central directory')
                except Exception as e:
                    print(f'Error occurred while saving directory in central dir - {e}')

            else:
                print('Object type nor file or directory')
                raise Exception(f'Cannot determine object type of {path}')
            self.delete_fs_entity(path)
        else:
            print('Path cannot be None')

    def delete_fs_entity(self, path: str | os.PathLike) -> None:
        """
        Function for deleting book in given path, also can delete directory with save points;
        :param path: path to book
        :return: None
        """
        print('Delete fs entity invoked')
        if path is not None:

            # file branch
            if os.path.isfile(path):
                try:
                    if path.endswith(self.path_to_read_file):
                        print('You cannot delete your read file!')
                    else:
                        os.remove(path)
                        print('Book deleted from directory')
                except Exception as e:
                    print(f'Exception occurred in deleting book in {path} - {e}')

            # directory branch
            elif os.path.isdir(path):
                try:
                    shutil.rmtree(path)
                    print(f'Directory {path} deleted')
                except Exception as e:
                    print(f'Exception occurred in deleting directory in {path} - {e}')
        else:
            print('Path cannot be None')

    def copy_fs_entity(self, path: str | os.PathLike, dir_name: str = '') -> None:
        """
        Save your book in central directory (app installation home).
        :param path: path from where you want to copy read book.
        :param dir_name: *optional parameter, special for directory copying. Use for creating new directory and copy all into
        :return: None
        """
        print('Copy fs entity invoked')
        if path is not None:

            # file branch
            if os.path.isfile(path):
                try:
                    shutil.copy2(path, self.current_dir)  # {src} {dest}
                    print('Book save in central directory')
                except Exception as e:
                    print(f'Error occurred while saving book in central dir - {e}')

            # directory branch
            elif os.path.isdir(path):
                try:
                    new_save_point_path = self.current_dir + os.sep + dir_name
                    os.mkdir(new_save_point_path)  # create new directory, instead of deleting old
                    shutil.copytree(path, new_save_point_path, dirs_exist_ok=True)  # {src} {dest}
                    print('Directory save in central directory')
                except Exception as e:
                    print(f'Error occurred while saving directory in central dir - {e}')

            else:
                print('Object type nor file or directory')
                raise Exception(f'Cannot determine object type of {path}')
            self.delete_fs_entity(path)
        else:
            print('Path cannot be None')

    def creation_date(self, path_to_file: str | os.PathLike) -> str:
        """
        Try to get the date that a file was created, falling back to when it was
        last modified if that isn't possible.
        See http://stackoverflow.com/a/39501288/1709587 for explanation.
        """
        if platform.system() == 'Windows':
            return str(os.path.getctime(path_to_file))
        elif platform.system() == 'Linux':
            try:
                mtime = os.path.getmtime(path_to_file)
                mtime_readable = datetime.date.fromtimestamp(mtime)
                return str(mtime_readable)
            except AttributeError:
                return str(datetime.datetime.now())
        else:
            raise NotImplemented('It seems that you have Mac operating system, not implemented for this system')
