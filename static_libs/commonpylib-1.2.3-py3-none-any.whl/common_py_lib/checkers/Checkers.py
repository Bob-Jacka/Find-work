import io
import os


def is_binary(stream):
    """
    Checks that stream is binary stream
    :param stream:
    :return:
    """
    mode = getattr(stream, 'mode', None)
    if mode:
        return 'b' in mode
    return not isinstance(stream, io.TextIOBase)


def is_dir(path: str):
    """
    Checks that given path is directory
    :param path: string path
    :return: bool value of result
    """
    return os.path.exists(path) and os.path.isdir(path)
