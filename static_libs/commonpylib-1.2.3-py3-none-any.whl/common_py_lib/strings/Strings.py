"""
Some strings actions
"""

def clear_str(to_clear: str) -> str:
    for cha in to_clear:
        if cha == '\'':
            to_clear.replace(cha, '')
        elif cha == '[' or cha == ']':
            to_clear.replace(cha, '')
    return to_clear  # return cleared string

def to_real_world_string(string: str):
    """
    In real world we encapsulate strings in double quotes
    :param string: string to encapsulate
    :return: Encapsulated string
    """
    return f'"{string}"'